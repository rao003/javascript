import kaboom from "kaboom"

// initialize context
kaboom()

// load assets
loadSprite("spieler", "sprites/ninja.png")
loadSprite("gegner2", "sprites/ghosty.png")
loadSprite("hintergrund", "sprites/dojo.jpg")
loadSprite("game over", "sprites/end.jpeg")
loadSprite("game start", "sprites/game.jpeg")
loadSprite("item", "sprites/banana.png")
loadSprite("gegner", "sprites/bat.png")
loadSprite("boden", "sprites/boden.png")
// add a character to screen

scene("game start", () => {
  add([
    sprite("game start", { width: width(), height: height() })
  ])
})
scene("gameover", () => {
  add([
    sprite("game over", { width: width(), height: height() })
  ]);
  add([
    text("Anzahl der Punkte. " + Punkte),
    pos(0, 30),
    scale(0.5)
  ])

})


let Punkte = 0;
scene("game", () => {


  add([
    sprite("hintergrund", { width: width(), height: height() })
  ])
  const punkte = add([
    text("Anzahl der Punkte. " + Punkte),
    pos(0, 30),
    scale(0.5)
  ])
  add([
    rect(width(), 10),
    color(128, 220, 23),
    pos(0, height() - 10),
    area(),
    solid()
  ])
  loop(3, () => {
    add([
      sprite("gegner2"),
      pos(rand(1, 600), 0),
      area(),
      scale(0.5),

      move(DOWN, 140),
      "gegner2"
    ]);
  });
  const player = add([
    sprite("spieler"),
    pos(0, 200),
    area(),
    scale(0.1),
    body(10000)
  ])


  sprite("boden"),
    pos(0, 0.50),
    area(),
    scale(1.5),
    solid()

  loop(5, () => {
    add([
      sprite("item"),
      pos(rand(0, 600), 0),
      area(),
      scale(0.1),
      move(DOWN, 140),
      "banane"]);

  });
  loop(5, () => {
    add([
      sprite("gegner"),
      pos(rand(1, 600), 0),
      area(),
      scale(0.2),
      move(DOWN, 120),
      "fledermaus"
    ]);
  });
  // add a kaboom on mouse click
  onClick(() => {
    addKaboom(mousePos())
  })

  // burp on "b"
  onKeyPress("up", () => {

    if (player.isGrounded()) {
      player.jump()
    }
  })
  onKeyDown("left", () => {
    if (player.pos.x >
      0) { player.move(-1000, 0) }
  })
  onKeyDown("up", () => player.move(0, +500))
  onKeyDown("right", () => {
    if (player.pos.x < width() - 50) { player.move(+1000, 0) }
  })
  player.onCollide("banane", (banane) => {
    destroy(banane);
    Punkte = Punkte + 1
    punkte.text = Punkte
  })
  player.onCollide("fledermaus", (fledermaus) => {
    go("gameover")
    destroy(fledermaus)
  })

  player.onCollide("gegner2", (gegner2) => {
    destroy(gegner2);
    Punkte = Punkte - 1
    punkte.text = Punkte
  })

})
go("game")
let punkte = 0;