import kaboom from "kaboom"
 kaboom({width: 600,
        height: 400})
loadSprite("hintergrund", "sprites/hintergrund.jpeg")
loadSprite("spieler", "sprites/ninja.png")
add([sprite("hintergrund", {width: 600,
        height: 400})])
 const player = add([
    sprite("spieler"),
    pos(0, 200),
    area(),
    scale(0.1),
   body()
    
  ])
 add([
    rect(width(), 10),
    color(0, 0, 0),
    pos(0, height() - 10),
    area(),
    solid()
  ])
 onKeyDown("right", () => {
    if (player.pos.x < width() - 50) { player.move(+1000, 0) }
  })
 onKeyDown("left", () => {
    if (player.pos.x >
      0) { player.move(-1000, 0) }
  })
