import kaboom from "kaboom"


kaboom()


loadSprite("cody", "sprites/cody.png")
loadSprite("hintergrund", "sprites/hintergrund jungel.png")
loadSprite("banana", "sprites/banana.png")

add([
  sprite("hintergrund", {width:width(), height:height()})
])

loop(5, () => {
    add([
    	sprite("banana"),
    	pos(randi(0,width()), randi(0,height())),
      scale(0.07),
    	area(),
      lifespan(5),
      "banana"
  ])
})


player = add([
	sprite("cody"),
	pos(80, 40),
  scale(0.15),
	area(),
])



player.onCollide("banana", (banana) => {
  destroy(banana)
});


